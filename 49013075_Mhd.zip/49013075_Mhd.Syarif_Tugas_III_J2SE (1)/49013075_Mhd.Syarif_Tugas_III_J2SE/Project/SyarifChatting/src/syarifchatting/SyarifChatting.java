/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package syarifchatting;

/**
 * @author MhdSyarif
 * Monday, 13 January 2014, 20 : 51 : 56 WIB 
 * Tugas III Matakulia Java2SE
 * Mhd. Syarif | 49013075
 * TKJMD - STEI - ITB
 */
public class SyarifChatting {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Server s = new Server();
        s.setVisible(true);
        // TODO code application logic here
    }
}
